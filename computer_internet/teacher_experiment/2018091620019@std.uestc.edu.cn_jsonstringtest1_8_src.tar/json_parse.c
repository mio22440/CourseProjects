#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cJSON.h"

#define MAX_ID_LEN 8
#define MAX_NAME_LEN 9
#define MIN_NAME_LEN 5

typedef enum _type{STUDENT, TEACHER} Type;
typedef enum _gender{MALE, FEMALE} Gender;

typedef struct _contacts Contacts;

struct _contacts{
	char id[MAX_ID_LEN+1];
	char name[MAX_NAME_LEN+1];
	Gender gender;
	Type type;
	char *mobile_phones;
};

int parseTheContact(void);


int main(int argc, char **argv){
    //freopen("input.txt", "r", stdin);

    parseTheContact();

    return 0;
}

int parseTheContact(void){
    char inputStringArray[2009] = {0};
    scanf("%s", inputStringArray);

    cJSON *addrBookJson = cJSON_Parse(inputStringArray);

    cJSON *stuObjctJson = cJSON_GetObjectItem(addrBookJson, "student");
    cJSON *teaObjctJson = cJSON_GetObjectItem(addrBookJson, "teacher");

    cJSON *stuContactArray = cJSON_GetObjectItem(stuObjctJson, "contacts");
    cJSON *teaContactArray = cJSON_GetObjectItem(teaObjctJson, "contacts");

    cJSON *stuAmountJson = cJSON_GetObjectItem(stuObjctJson, "amount");
    cJSON *teaAmountJson = cJSON_GetObjectItem(teaObjctJson, "amount");
    int stuAmount = stuAmountJson->valueint;
    int teaAmount = teaAmountJson->valueint;

    cJSON *tempStuContactJson;
    cJSON *tempTeaContactJson;
    cJSON *tempItemJson1;
    cJSON *tempItemJson2;
    int tempPhoneArraySize;

    int i = 0;
    for(i=0; i<stuAmount; i++){
        tempStuContactJson = cJSON_GetArrayItem(stuContactArray, i);
        
        tempItemJson1 = cJSON_GetObjectItem(tempStuContactJson, "id");
        printf("%s 0 ", tempItemJson1->valuestring);

        tempItemJson1 = cJSON_GetObjectItem(tempStuContactJson, "name");
        printf("%s ", tempItemJson1->valuestring);

        tempItemJson1 = cJSON_GetObjectItem(tempStuContactJson, "gender");
        printf("%d ", tempItemJson1->valueint);

        tempItemJson1 = cJSON_GetObjectItem(tempStuContactJson, "mobile_phones");
        tempPhoneArraySize = cJSON_GetArraySize(tempItemJson1);
        tempItemJson2 = cJSON_GetArrayItem(tempItemJson1, 0);
        printf("%s", tempItemJson2->valuestring);
        if(tempPhoneArraySize > 1){
            printf(",");
            tempItemJson2 = cJSON_GetArrayItem(tempItemJson1, 1);
            printf("%s", tempItemJson2->valuestring);
        }
        printf("\n");
    }

    for(i=0; i<teaAmount; i++){
        tempTeaContactJson = cJSON_GetArrayItem(teaContactArray, i);
        
        tempItemJson1 = cJSON_GetObjectItem(tempTeaContactJson, "id");
        printf("%s 1 ", tempItemJson1->valuestring);

        tempItemJson1 = cJSON_GetObjectItem(tempTeaContactJson, "name");
        printf("%s ", tempItemJson1->valuestring);

        tempItemJson1 = cJSON_GetObjectItem(tempTeaContactJson, "gender");
        printf("%d ", tempItemJson1->valueint);

        tempItemJson1 = cJSON_GetObjectItem(tempTeaContactJson, "mobile_phones");
        tempPhoneArraySize = cJSON_GetArraySize(tempItemJson1);
        tempItemJson2 = cJSON_GetArrayItem(tempItemJson1, 0);
        printf("%s", tempItemJson2->valuestring);
        if(tempPhoneArraySize > 1){
            printf(",");
            tempItemJson2 = cJSON_GetArrayItem(tempItemJson1, 1);
            printf("%s", tempItemJson2->valuestring);
        }
        printf("\n");
    }


    return 0;
}