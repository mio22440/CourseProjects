#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cJSON.h"

#define MAX_ID_LEN 8
#define MAX_NAME_LEN 9
#define MIN_NAME_LEN 5

typedef enum _type{STUDENT, TEACHER} Type;
typedef enum _gender{MALE, FEMALE} Gender;

typedef struct _contacts Contacts;

struct _contacts{
	char id[MAX_ID_LEN+1];
	char name[MAX_NAME_LEN+1];
	Gender gender;
	Type type;
	char *mobile_phones;
};


int printContact(Contacts *contact);
cJSON *CreateContactJson(void);

int main(){

    //freopen("input.txt", "r", stdin);
	
	cJSON *ContactJson = CreateContactJson();

    printf("%s", cJSON_Print(ContactJson));


    return 0;
}

int printContact(Contacts *contact){
    printf("%s\t%s\t%d\t%d\t%s\n", contact->id,
        contact->name,
        contact->gender,
        contact->type,
        contact->mobile_phones
    );
}

cJSON *CreateContactJson(void){
    cJSON *addrBook = NULL;//tong xun lu
    cJSON *stuObjct = NULL;
    cJSON *teaObjct = NULL;

    int totalAmount = 0;//to control the array
    //int sduAmount = 0;
    //int teaAmount = 0;

    int stuMalNum = 0, stuFmlNum = 0;
    int teaMalNum = 0, teaFmlNum = 0;

    //float stuMalRat = 0, stuFmlRat = 0;
    //float teaMalRat = 0, teaFmlRat = 0;

    Contacts *temp;
    Contacts contactArray[100];

    temp = (Contacts*)calloc(1, sizeof(Contacts));
    temp->mobile_phones = (char*)calloc(25, sizeof(char));

    int tempInt;
    char tempRatio[4] = "00%";
    char tempchar[2];
    char tempString[25];

    cJSON *tempStuJson, *tempTeaJson;

    
    /*get all info*/
    //tempchar[0] = getchar();
    tempchar[1] = getchar();
    while(/*(tempchar[0] != '\n') || */(tempchar[1] != '\n')){
        //read data
        //temp->id[0] = tempchar[0];
        temp->id[0] = tempchar[1];
        scanf("%s", temp->id+1);
        scanf("%d", &tempInt);
        if(0 == tempInt)
            temp->type = STUDENT;
        else if(1 == tempInt)
            temp->type = TEACHER;
        else{
            printf("--illegal input--\n");
            return NULL;
        }
        scanf("%s", temp->name);

        scanf("%d", &tempInt);
        if(0 == tempInt)
            temp->gender = MALE;
        else if(1 == tempInt)
            temp->gender = FEMALE;
        else{
            printf("--illegal input--\n");
            return NULL;
        }

        scanf("%s", tempString);
        strcpy(temp->mobile_phones, tempString);
        if(temp->mobile_phones[11] == ','){
            temp->mobile_phones[11] = '\0';
        }
        else{
            temp->mobile_phones[12] = -1;//to judge if there is only one phone
                                //number
        }
        

        //now the struct is created, create the json object
        if(temp->type == STUDENT){
            if(temp->gender == MALE){
                stuMalNum++;
            }
            else
            {
                stuFmlNum++;
            }
            
        }
        else{
            if(temp->gender == MALE){
                teaMalNum++;
            }
            else
            {
                teaFmlNum++;
            }
            
        }

        contactArray[totalAmount++] = *temp;

        temp = (Contacts*)calloc(1, sizeof(Contacts));
        temp->mobile_phones = (char*)calloc(25, sizeof(char));

        tempchar[0] = getchar();
        tempchar[1] = getchar();
    }

    addrBook = cJSON_CreateObject(); 
    cJSON_AddNumberToObject(addrBook, "amount", totalAmount);

    /*add student object and teacher object*/
    stuObjct = cJSON_CreateObject();
    teaObjct = cJSON_CreateObject();
    cJSON_AddNumberToObject(stuObjct, "amount", stuMalNum+stuFmlNum);
    cJSON_AddNumberToObject(teaObjct, "amount", teaMalNum+teaFmlNum);

    /*student ratio*/
    int tempRatioInt = (int)((((float)stuMalNum)/(stuMalNum+stuFmlNum))*100+0.5);
    if((0 != tempRatioInt) && (100 != tempRatioInt)){
        tempRatio[1] = tempRatioInt%10+'0';
        tempRatio[0] = tempRatioInt/10+'0';
        cJSON_AddStringToObject(stuObjct, "male_ratio", tempRatio); 
        if(tempRatio[1] != '0'){  
            tempRatio[1] = (10+'0'-tempRatio[1])+'0';
            tempRatio[0] = (9+'0'-tempRatio[0])+'0';
        }
        else{
            tempRatio[0] = (10+'0'-tempRatio[0])+'0';
        }
        cJSON_AddStringToObject(stuObjct, "female_ratio", tempRatio);
    }
    else{
        if(0 == tempRatioInt){
            cJSON_AddStringToObject(stuObjct, "male_ratio", "0%");
            cJSON_AddStringToObject(stuObjct, "female_ratio", "100%");
        }
        else{
            cJSON_AddStringToObject(stuObjct, "male_ratio", "100%");
            cJSON_AddStringToObject(stuObjct, "female_ratio", "0%");
        }
    }

    /*teacher ratio*/
    tempRatioInt = (int)((((float)teaMalNum)/(teaMalNum+teaFmlNum))*100+0.5);
    if((0 != tempRatioInt) && (100 != tempRatioInt)){
        tempRatio[1] = tempRatioInt%10+'0';
        tempRatio[0] = tempRatioInt/10+'0';
        cJSON_AddStringToObject(teaObjct, "male_ratio", tempRatio); 
        if(tempRatio[1] != '0'){  
            tempRatio[1] = (10+'0'-tempRatio[1])+'0';
            tempRatio[0] = (9+'0'-tempRatio[0])+'0';
        }
        else{
            tempRatio[0] = (10+'0'-tempRatio[0])+'0';
        }
        cJSON_AddStringToObject(teaObjct, "female_ratio", tempRatio);
    }
    else{
        if(0 == tempRatioInt){
            cJSON_AddStringToObject(teaObjct, "male_ratio", "0%");
            cJSON_AddStringToObject(teaObjct, "female_ratio", "100%");
        }
        else{
            cJSON_AddStringToObject(teaObjct, "male_ratio", "100%");
            cJSON_AddStringToObject(teaObjct, "female_ratio", "0%");
        }
    }
    

    cJSON *stuContactArray = cJSON_CreateArray();
    cJSON *teaContactArray = cJSON_CreateArray();
    cJSON *contactPhonNumArray;

    char tempPhNum1[12], tempPhNum2[12];
    tempPhNum1[11] = '\0';
    tempPhNum2[11] = '\0';

    int i = 0;
    for(i=0; i<totalAmount; i++){
        if(STUDENT == contactArray[i].type){//create student json object
            tempStuJson = cJSON_CreateObject();
            cJSON_AddStringToObject(tempStuJson, "id", contactArray[i].id);
            cJSON_AddStringToObject(tempStuJson, "name", contactArray[i].name);
        
            if(contactArray[i].gender == MALE){
                cJSON_AddNumberToObject(tempStuJson, "gender", 0);
            }
            else{
                cJSON_AddNumberToObject(tempStuJson, "gender", 1);
            }

            contactPhonNumArray = cJSON_CreateArray();
            strcpy(tempPhNum1, contactArray[i].mobile_phones);
            cJSON_AddItemToArray(contactPhonNumArray, cJSON_CreateString(tempPhNum1));
            if(contactArray[i].mobile_phones[12] != -1){
                strcpy(tempPhNum2, contactArray[i].mobile_phones+12);
                cJSON_AddItemToArray(contactPhonNumArray, cJSON_CreateString(tempPhNum2));
            }

            cJSON_AddItemToObject(tempStuJson, "mobile_phones", contactPhonNumArray);

            cJSON_AddItemToArray(stuContactArray, tempStuJson);
            
        }
        else{
            tempTeaJson = cJSON_CreateObject();
            cJSON_AddStringToObject(tempTeaJson, "id", contactArray[i].id);
            cJSON_AddStringToObject(tempTeaJson, "name", contactArray[i].name);
        
            if(contactArray[i].gender == MALE){
                cJSON_AddNumberToObject(tempTeaJson, "gender", 0);
            }
            else{
                cJSON_AddNumberToObject(tempTeaJson, "gender", 1);
            }

            
            contactPhonNumArray = cJSON_CreateArray();
            strcpy(tempPhNum1, contactArray[i].mobile_phones);
            cJSON_AddItemToArray(contactPhonNumArray, cJSON_CreateString(tempPhNum1));
            if(contactArray[i].mobile_phones[12] != -1){
                strcpy(tempPhNum2, contactArray[i].mobile_phones+12);
                cJSON_AddItemToArray(contactPhonNumArray, cJSON_CreateString(tempPhNum2));
            }

            cJSON_AddItemToObject(tempTeaJson, "mobile_phones", contactPhonNumArray);

            cJSON_AddItemToArray(teaContactArray, tempTeaJson);
            
        }
    }
    cJSON_AddItemToObject(stuObjct, "contacts", stuContactArray);
    cJSON_AddItemToObject(teaObjct, "contacts", teaContactArray);

    cJSON_AddItemToObject(addrBook, "student", stuObjct);
    cJSON_AddItemToObject(addrBook, "teacher", teaObjct);

    return addrBook;
}

