//---------------------------include start
#include <stdio.h>
#include <strings.h>
#include <string.h>

#include <netinet/in.h>//sockaddr_in

#include <stdlib.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>

#include <unistd.h>//close()

#include <signal.h>//sigaction {str sig}

#include <errno.h>//errno
//#include <bits/sigaction.h>

//---------------------------include end

//---------------------------define start
//#define SERV_PORT 9877
#define MAX_CMD_STR 100
//---------------------------define end

//---------------------------func declaration start
void echo_rep(int listenfd);
void sig_int(int signo);
void sig_pipe();
//---------------------------func declaration end

//---------------------------global var dec start
int pipeRcvd = 0;
int sig_to_exit = 0;
//---------------------------global var dec end

int main(int argc, char *argv[]){
    int listenfd;
    //int serv_port;
    struct sockaddr_in servaddr;

    if(argc != 3){
        printf("myTcpServ:usage: myTcpServ <IPaddress> <Port>\n");
        return -1;
    }

    //register the signal function

    struct sigaction sigact_pipe, old_sigact_pipe;
    sigact_pipe.sa_handler = sig_pipe;
    sigemptyset(&sigact_pipe.sa_mask);
    sigact_pipe.sa_flags = 0;
    sigact_pipe.sa_flags |= SA_RESTART;
    sigaction(SIGPIPE, &sigact_pipe, &old_sigact_pipe);

    struct sigaction sigact_int;
    sigact_int.sa_handler = sig_int;
    sigemptyset(&sigact_int.sa_mask);
    sigact_int.sa_flags = 0;
    sigaction(SIGINT, &sigact_int, NULL);



    while((listenfd = socket(AF_INET,SOCK_STREAM,0)) == -1);
    //printf("get the listenfd~\n");

    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    //servaddr.sin_port = htons(SERV_PORT);
    servaddr.sin_port = htons(atoi(argv[2]));
    inet_pton(AF_INET, argv[1], &(servaddr.sin_addr));

    printf("[srv] server[%s:%s] is initializing!\n", argv[1], argv[2]);

    if(bind(listenfd, (struct sockaddr*)&servaddr, sizeof(struct sockaddr)) < 0){
        printf("[srv] fail to bind\n");
        return -1;
    }

    listen(listenfd, 5);

    int connfd;
    struct sockaddr_in cli_addr;
    int sin_size = sizeof(struct sockaddr_in);
    char IPdotdec[20] = {0};
    char strPort[8] = {0};
    while(1){
        connfd = accept(listenfd, (struct sockaddr*)&cli_addr, &sin_size);
        if(connfd == -1 && errno == EINTR){
            break;
        }

        if(-1 == connfd){
            printf("[srv] fail to accept!\n");
        }
        else{
            inet_ntop(AF_INET, &cli_addr.sin_addr, IPdotdec, 16);
            sprintf(strPort, "%d", htons(cli_addr.sin_port));
            printf("[srv] client[%s:%s] is accepted!\n", IPdotdec, strPort);
            echo_rep(connfd);
            close(connfd);
            printf("[srv] connfd is closed!\n");
        }

        if(1 == sig_to_exit){
            break;
        }
    }

    while(0 != close(listenfd));

    printf("[srv] listenfd is closed!\n");
    printf("[srv] server is going to exit!\n");

    return 0;

}

void echo_rep(int connfd){
    char buf[101] = {0};
    char *p = buf;
    int len = 0;
    int readCnt = 0;
    

    while(1){
        if(1 == sig_to_exit){
            return;
        }

        pipeRcvd = 0;
        readCnt = 0;
        readCnt = read(connfd, &len, sizeof(len));
        
        if(readCnt != 0)
            readCnt = read(connfd, buf, len);
        //if(1 == pipeRcvd){
        //    printf("[srv] connfd is closed!\n");
        //    return;
        //}
        if(readCnt == 0){
            return;
        }
        
        printf("[echo_rqt] %s\n", buf);


        //len = strnlen(buf, MAX_CMD_STR);
        //write(connfd, &len, sizeof(len));
        write(connfd, &len, sizeof(len));
        write(connfd, buf, len);
        if(1 == pipeRcvd){
            //printf("[srv] connfd is closed!\n");
            return;
        }
        memset(buf, 0, sizeof(buf));
        
    }
}

void sig_int(int signo){
    printf("[srv] SIGINT is coming!\n");
    sig_to_exit = 1;
}

void sig_pipe(){
    printf("[srv] SIGPIPE is coming!\n");
    pipeRcvd = 1;
}