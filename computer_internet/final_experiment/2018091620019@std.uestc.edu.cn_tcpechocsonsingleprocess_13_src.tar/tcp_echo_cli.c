#include <stdio.h>
#include <strings.h>
#include <string.h>

#include <netinet/in.h>//sockaddr_in

#include <stdlib.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>

#include <unistd.h>//close()

//#define SERV_PORT 9877
#define MAX_CMD_STR 100

void echo_rqt(int sockfd);

int main(int argc, char *argv[]){
    int sockfd;
    //int serv_port;
    struct sockaddr_in servaddr;

    if(argc != 3){
        printf("myTcpCli:usage: myTcpCli <IPaddress> <Port>\n");
        return -1;
    }

    while((sockfd = socket(AF_INET,SOCK_STREAM,0)) == -1);
    //printf("get the sockfd~\n");

    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    //servaddr.sin_port = htons(SERV_PORT);
    servaddr.sin_port = htons(atoi(argv[2]));
    inet_pton(AF_INET, argv[1], &(servaddr.sin_addr));

    while(0 != connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)));

    printf("[cli] server[%s:%s] is connected!\n", argv[1], argv[2]);

    echo_rqt(sockfd);

    while(0 != close(sockfd));

    printf("[cli] connfd is closed!\n");
    printf("[cli] client is goting to exit!\n");

    return 0;

}

void echo_rqt(int sockfd){
    char buf[MAX_CMD_STR+1] = {0};
    char *p = buf;
    int len = 0;

    while(1){
        p = buf;
        *p = getchar();
        while(*p!='\n'&&p<buf+99){
            *(++p) = getchar();
        }
        //*p = '\0';
        if(strncmp(buf, "exit", 4) == 0){
            return;
        }

        len = strnlen(buf, MAX_CMD_STR);

        *p = '\0';

        //printf("%d\n", len);

        write(sockfd, &len, sizeof(len));
        write(sockfd, buf, len);
        memset(buf, 0, sizeof(buf));
        read(sockfd, &len, sizeof(len));
        read(sockfd, buf, len);
        printf("[echo_rep] %s\n", buf);
        memset(buf, 0, sizeof(buf));
    }
}